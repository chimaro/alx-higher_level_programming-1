#!/usr/bin/python3
def copy_list(mylist):
    return (mylist.copy())

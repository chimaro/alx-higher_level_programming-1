# solution to tasks on 0x08. Python - More Classes and Objects

# Solutions to tasks on 0x06. Python - Classes and Objects 

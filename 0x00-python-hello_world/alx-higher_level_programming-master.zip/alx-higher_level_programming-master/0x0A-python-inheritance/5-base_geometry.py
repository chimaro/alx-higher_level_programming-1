#!/usr/bin/python3
"""An empty class"""


class BaseGeometry:
    """This is an empty class"""
    pass

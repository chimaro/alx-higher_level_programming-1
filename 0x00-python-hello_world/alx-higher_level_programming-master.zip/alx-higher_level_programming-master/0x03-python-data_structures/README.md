Solution to tasks on Python data structures

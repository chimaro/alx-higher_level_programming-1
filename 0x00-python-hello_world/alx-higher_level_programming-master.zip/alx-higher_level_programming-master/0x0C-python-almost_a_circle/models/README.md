# Models


This folder contains three classes. They are:
 - Base: The base for all models. Defines the id of objects and keeps a record of all models created.
 - Rectangle: Inherits from Base.
 - Square: Inherits from Rectangle.:wq


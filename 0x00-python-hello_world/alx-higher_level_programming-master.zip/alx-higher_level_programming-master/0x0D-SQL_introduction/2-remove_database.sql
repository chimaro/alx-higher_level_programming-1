-- script that remove database hbtn_0c_0
-- does not fail
DROP DATABASE IF EXISTS hbtn_0c_0;

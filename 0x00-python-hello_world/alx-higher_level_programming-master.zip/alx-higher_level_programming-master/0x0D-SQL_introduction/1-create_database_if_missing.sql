-- script that creates database hbtn_0c_0
-- does not fail
CREATE DATABASE IF NOT EXISTS hbtn_0c_0;

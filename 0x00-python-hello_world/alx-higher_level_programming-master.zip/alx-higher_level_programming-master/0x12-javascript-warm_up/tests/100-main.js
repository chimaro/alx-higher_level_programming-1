#!/usr/bin/node
myVar = 89;
require('../100-let_me_const');
console.log(myVar);

#!/usr/bin/node
exports.add = (a, b) => a + b;

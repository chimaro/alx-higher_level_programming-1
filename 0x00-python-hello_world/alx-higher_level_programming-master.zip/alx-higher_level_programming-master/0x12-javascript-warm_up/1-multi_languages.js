#!/usr/bin/node

// Script that prints C is fun,Python is cool and JavaScript is amazing.

const myVar = 'C is fun\nPython is cool\nJavaScript is amazing';
console.log(myVar);
